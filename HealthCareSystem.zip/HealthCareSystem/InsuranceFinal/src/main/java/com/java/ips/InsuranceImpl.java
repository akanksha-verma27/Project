package com.java.ips;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class InsuranceImpl {

	SessionFactory sf;
	Session session;
	
	static String orderByInsuranceId = "asc";
	static String orderByInsuranceName = "test";
	static String orderByType = "test";
	static String orderByPremiumStart = "test";
	static String orderByPremiumEnd = "test";
	static String orderByMinPeriod = "test";
	static String orderByMaxPeriod = "test";
	static String orderByLaunchDate = "test";
	static String orderByStatus = "test";

	
	public String sortByInsuranceId() {
		Map<String, Object> sessionMap = 
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if(orderByInsuranceId.equals("desc") || orderByInsuranceId.equals("test")) {
			orderByInsuranceId = "asc";
			orderByInsuranceName = "test";
			orderByType = "test";
			orderByPremiumStart = "test";
			orderByPremiumEnd = "test";
			orderByMinPeriod = "test";
			orderByMaxPeriod = "test";
			orderByLaunchDate = "test";
			orderByStatus = "test";
		}else if(orderByInsuranceId.length() == 3){
			orderByInsuranceId = "desc";
			orderByInsuranceName = "test";
			orderByType = "test";
			orderByPremiumStart = "test";
			orderByPremiumEnd = "test";
			orderByMinPeriod = "test";
			orderByMaxPeriod = "test";
			orderByLaunchDate = "test";
			orderByStatus = "test";
		}
		sessionMap.put("insurance_id", orderByInsuranceId);
		sessionMap.put("insurance_Name", orderByInsuranceName);
		sessionMap.put("type", orderByType);
		sessionMap.put("PremiumStart", orderByPremiumStart);
		sessionMap.put("premiumEnd", orderByPremiumEnd);
		sessionMap.put("minPeriod", orderByMinPeriod);
		sessionMap.put("maxPeriod", orderByMaxPeriod);
		sessionMap.put("launchDate", orderByLaunchDate);
		sessionMap.put("status", orderByStatus);
		return "showPlans.jsp?faces-redirect=true";
	}
	
	public List<Insurance_Details> searchInsuranceDao(int firstRow, int rowCount, String searchValue, String startTime, String endTime){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String, Object> sessionMap =
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		String searchTypeStr = (String) sessionMap.get("searchTypeStr");
		String searchMethodStr = (String) sessionMap.get("searchMethod");
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Insurance_Details.class);
		criteria.add(Restrictions.eq("Insurance_id", "I001"));
		if(orderByInsuranceId.equals("asc")) {
			criteria.addOrder(Order.asc("insurance_id"));
		}else if(orderByInsuranceId.equals("desc")) {
			criteria.addOrder(Order.desc("insurance_id"));
		}
		criteria.setFirstResult(firstRow);
		criteria.setMaxResults(rowCount);
		return criteria.list();
	}

	public int countRows(String searchValue) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String, Object> sessionMap = 
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		String searchTypeStr = (String) sessionMap.get("searchTypeStr");
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		try {
			session.beginTransaction();
			Criteria criteria = session.createCriteria(Insurance_Details.class);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	private String localCode;

	public String getLocalCode() {
		return localCode;
	}

	public void setLocalCode(String localCode) {
		this.localCode = localCode;
	}

	public List<Insurance_Details> showInsurance() {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Query query = session.createQuery("from Insurance_Details");
		List<Insurance_Details> insdet = query.list();
		return insdet;
	}

	public String showInsurancePlans(String insurance_id) {
		System.out.println("explore plans");
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
	Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();				
		session.beginTransaction();
		Criteria criteria = session.createCriteria(Insurance_Plans.class);
		criteria.add(Restrictions.eq("insurance_id", insurance_id));
		List<Insurance_Plans> showList = criteria.list();
		sessionMap.put("showList",showList);	
		return "showPlans.jsp?faces-redirect=true";
		
	}
	
	public String takeToinsurancePlan(String insurance_id) {
		System.out.println(insurance_id);
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		
		sessionMap.put("insurance_id", insurance_id);
		return "ExplorePlans.jsp?faces-redirect=true"; 
	}

	public List<Insurance_Details> showInsuranceDetailsDao(int firstRow, int rowCount) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Insurance_Details.class);
		cr.setFirstResult(firstRow);
		cr.setMaxResults(rowCount);
		System.out.println(firstRow);
		System.out.println(rowCount);
		System.out.println(cr.list());
		return cr.list();
	}
	
	public List<Insurance_Details> getListOfInsurance(int firstRow, int rowCount) {
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		List<Insurance_Details> cdList = null;
		
		session.beginTransaction();
		Criteria criteria = session.createCriteria(Insurance_Details.class);
		criteria.setFirstResult(firstRow);
		criteria.setMaxResults(rowCount);
		return criteria.list();
	}

	
	public String searchByinsurance_id(int insurance_id) {
		sf = SessionHelper.getConnection();
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		session = sf.openSession();
		Criteria criteria = session.createCriteria(Insurance_Details.class);
		criteria.add(Restrictions.eq("insurance_id", insurance_id));
		List<Insurance_Details> insList = criteria.list();
		sessionMap.put("insList", insList);
		return "showPlans.jsp?faces-redirect=true";
		}
	public int countRows() {
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		try {
			session.beginTransaction();
			Criteria criteria = session.createCriteria(Insurance_Details.class);
			if (criteria != null) {
				return criteria.list().size();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	}
